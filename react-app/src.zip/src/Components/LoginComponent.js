import { useState } from "react";
import ClientService from "../Service/ClientService";
import { Link, useNavigate } from "react-router-dom";
import './Login.css';

const LoginComponent = ({  }) => {


  const navigate = useNavigate();
  const [clientId, setClientId] = useState(localStorage.getItem('clientId'))
  const [password, setPassword] = useState('');
  const [error, setError] = useState('')
  const handleClientIdChange = (e) => {
    setClientId(e.target.value);
  };
  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {

      const response = await ClientService.loginClient(clientId, password);

      if (response.status === 200) {

        console.log('User logged in: ', clientId);

        setClientId(clientId);
        localStorage.setItem('clientId', clientId);
        setPassword('');
        navigate('/user');
      } else {
        setError('Invalid id or password');
      }
    } catch (error) {
      console.error('Login failed:', error);
      setError('Login failed. Please try again.');
    }
  };
  const handleSignUp = () => {
    navigate("/signup");
  };
  return (

    <div className="text-center1">
      <div className="login-form">
        <h2>Login</h2>
        <form onSubmit={handleSubmit}>
          {error && <div className="error">{error}</div>}
          <div className="fields">
            <div className="col-5 ">
              <label htmlFor="ClientId">LOGIN ID: </label>
              <input
                type="clientId"
                id="clientId"
                value={clientId}
                onChange={handleClientIdChange}
                required />
            </div>
          </div>
          <div className="fields">
            <div className="col-5 ">
              <label htmlFor="password">Password:</label>
              <input type="password"
                id="password"
                value={password}
                onChange={handlePasswordChange} required />
            </div>
          </div>
          <button class="btn btn-primary" type="submit"  >Login</button>
          <Link to="/signup" onClick={handleSignUp}>Don't have an account? Sign up</Link>
        </form>
      </div>
    </div>
  );
};
export default LoginComponent;