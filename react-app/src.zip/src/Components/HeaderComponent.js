import React from 'react';  
import { Link} from 'react-router-dom';

const HeaderComponent =()=>{
 
  
    return(
        <div>
        <div>
            <header  style={{ position: 'fixed', top: 0, width: '100%', zIndex: 999 }}>  
            <nav className="navbar navbar-expand-md navbar-dark bg-dark">   
            <div><a href="https://javaguides.net" className="navbar-brand">Assign Work</a></div>

           <div className="navbar-collapse justify-content-end "> 
           <div className="navbar-collapse ml-auto">
        <ul className="navbar-nav mr-auto">
          <li className="nav-item">
            <Link className="nav-link" to="/about">
              About
            </Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/contact">
              Contact
            </Link>
          </li>
 
 
            <li className="nav-item">
            <Link className="nav-link"  to={'/user'}>Home</Link>
          </li>
          
          <li className="nav-item">
            <Link className="nav-link"  to={'/assignedWorks'}>Assigned Works</Link>
          </li>
      
        </ul>
      </div>

      <div >
        <Link type="button"   className="navbar-collapse justify-content-end btn btn-light" to={'/'} > LogOut</Link>
        
      </div> 
      </div> 
</nav> 
  </header>
        </div>
        </div>
    )
    }
    export default HeaderComponent